/**
 * Read-only observation of the active support conversation.
 *
 * The DOM is an untrusted data source. This module deliberately returns
 * message text only as data and only treats bounded semantic attributes as
 * workflow metadata; page attributes never self-authorize completion evidence.
 * Keep the Firefox copy byte-identical.
 */

(() => {
  if (typeof window.__wb_observe_chat_dom === 'function') return;

  const SCHEMA = 'webbrain-chat-observation/1';
  const MAX_TEXT = 4000;
  const MAX_ITEMS = 200;
  const MESSAGE_SELECTORS = [
    '[data-message-id]',
    '[data-legacy-message-id]',
    '[data-message-direction]',
    '[data-direction]',
    '[data-message-author-role]',
    '[data-author-role]',
    '[data-outgoing]',
    '[data-is-outgoing]',
    '[data-incoming]',
    '[data-is-incoming]',
    '[data-message]',
    '[role="listitem"]',
    'article',
  ];
  const THREAD_ID_ATTRIBUTES = [
    'data-conversation-id',
    'data-thread-id',
    'data-chat-id',
  ];
  const IDENTITY_ATTRIBUTES = [
    'data-conversation-identity',
    'data-recipient',
    'data-chat-recipient',
    'data-recipient-id',
  ];
  const CHAT_ROOT_SELECTORS = [
    '[data-chat-root]',
    '[data-conversation-root]',
    '[role="log"]',
  ];
  const CHAT_TRANSCRIPT_SELECTORS = [
    '[role="log"]',
    '[aria-live]',
  ];

  const compact = (value, max = 240) => String(value ?? '')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);

  const normalizeText = (value) => String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/\r\n?/g, '\n')
    .split('\n')
    .map(line => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join('\n')
    .slice(0, MAX_TEXT);

  // Mirrors the kernel's canonical form so the fallback ordinal below groups
  // exactly the bubbles the kernel would otherwise give the same id.
  const canonicalText = (value) => {
    const text = normalizeText(value);
    try { return text.normalize('NFKC').toLocaleLowerCase(); } catch { return text.toLowerCase(); }
  };

  const attribute = (node, name) => compact(node?.getAttribute?.(name), 1000);

  const visible = (node) => {
    if (!node || node.nodeType !== 1 || node.isConnected === false) return false;
    try {
      const style = getComputedStyle(node);
      const rect = node.getBoundingClientRect?.() || {};
      return style.display !== 'none'
        && style.visibility !== 'hidden'
        && (rect.width == null || rect.width > 0)
        && (rect.height == null || rect.height > 0);
    } catch {
      return false;
    }
  };

  const editable = (node) => {
    if (!node || node.nodeType !== 1) return false;
    const tag = String(node.tagName || '').toLowerCase();
    const type = attribute(node, 'type').toLowerCase();
    const role = attribute(node, 'role').toLowerCase();
    return !!node.isContentEditable
      || tag === 'textarea'
      || (tag === 'input' && !/^(button|submit|reset|checkbox|radio|file|image|range|color|hidden)$/.test(type || 'text'))
      || role === 'textbox'
      || role === 'searchbox';
  };

  const contains = (parent, child) => parent === child || !!parent?.contains?.(child);

  const query = (root, selector) => {
    try { return Array.from(root?.querySelectorAll?.(selector) || []); } catch { return []; }
  };

  const queryMany = (root, selectors) => {
    return query(root, (Array.isArray(selectors) ? selectors : []).filter(Boolean).join(','));
  };

  const parentChain = (node, limit = 20) => {
    const result = [];
    for (let current = node, depth = 0; current && depth < limit; depth += 1, current = current.parentElement) {
      result.push(current);
    }
    return result;
  };

  const firstAttribute = (nodes, names) => {
    for (const node of nodes) {
      for (const name of names) {
        const value = attribute(node, name);
        if (value) return { name, value, node };
      }
    }
    return null;
  };

  const booleanValue = (value, attributePresent = false) => {
    const normalized = compact(value, 40).toLowerCase();
    if (['true', 'yes', '1', 'verified', 'complete', 'connected', 'required'].includes(normalized)) return true;
    if (['false', 'no', '0', 'unverified', 'incomplete', 'disconnected', 'optional'].includes(normalized)) return false;
    return attributePresent && !normalized ? true : null;
  };

  const discordChannel = (composer) => {
    if (!composer || !/^(?:www\.)?discord\.com$/.test(window.location?.hostname || '')) return null;
    const route = /^\/channels\/(\d+)\/(\d+)(?:\/\d+)?\/?$/.exec(window.location?.pathname || '');
    const directMessageRoute = /^\/channels\/@me\/(\d+)(?:\/\d+)?\/?$/.exec(window.location?.pathname || '');
    if ((!route && !directMessageRoute)
        || !composer.matches?.('[data-slate-editor="true"][contenteditable="true"][role="textbox"]')) return null;
    const root = composer.closest('main,[role="main"]');
    if (!root || !visible(root)) return null;
    const transcript = query(root, '[data-list-id="chat-messages"]').find(node =>
      visible(node) && !contains(node, composer));
    const channelId = route?.[2] || directMessageRoute[1];
    const routePath = route
      ? `/channels/${route[1]}/${channelId}`
      : `/channels/@me/${channelId}`;
    const channelLink = query(document, 'nav a[href],[role="navigation"] a[href]').find(node => {
      try {
        const url = new URL(attribute(node, 'href'), window.location.href);
        return visible(node) && attribute(node, 'aria-current') === 'page' && url.origin === window.location.origin
          && url.pathname.replace(/\/$/, '') === routePath;
      } catch { return false; }
    });
    const selectedDmRouteMismatch = !!directMessageRoute
      && query(document, 'nav a[href][data-list-item-id^="private-channels-"],[role="navigation"] a[href][data-list-item-id^="private-channels-"]')
        .some(node => {
          try {
            const url = new URL(attribute(node, 'href'), window.location.href);
            const selectedDmChannelId = /^\/channels\/@me\/(\d+)(?:\/\d+)?\/?$/.exec(url.pathname)?.[1];
            return visible(node) && attribute(node, 'aria-current') === 'page'
              && url.origin === window.location.origin
              && !!selectedDmChannelId && selectedDmChannelId !== channelId;
          } catch { return false; }
        });
    const transcriptRows = query(transcript, '[role="article"]').filter(visible);
    const transcriptChannelIds = transcriptRows
      .map(node => /^chat-messages___chat-messages-(\d+)-\d+$/.exec(attribute(node, 'data-list-item-id'))?.[1])
      .filter(Boolean);
    const transcriptMatchesRoute = transcriptRows.length > 0
      && transcriptChannelIds.length === transcriptRows.length
      && transcriptChannelIds.every(id => id === channelId);
    const name = /^Message #(.+)$/.exec(attribute(composer, 'aria-label'))?.[1]
      || /^Messages in (.+)$/.exec(attribute(transcript, 'aria-label'))?.[1]
      || /^(.+) \(channel\)$/.exec(attribute(root, 'aria-label'))?.[1]
      || (directMessageRoute ? `direct-message-${channelId}` : `channel-${channelId}`);
    return transcript && (directMessageRoute
      ? !selectedDmRouteMismatch
        && (transcriptRows.length > 0 ? transcriptMatchesRoute : channelLink)
      : (transcriptRows.length > 0 ? transcriptMatchesRoute : channelLink))
      ? {
        root, transcript, name, channelId,
        isDirectMessage: !!directMessageRoute,
        id: directMessageRoute ? `discord:dm:${channelId}` : `discord:${route[1]}:${channelId}`,
      }
      : null;
  };

  const activeRoot = (composer) => {
    if (!composer) return null;
    const channel = discordChannel(composer);
    if (channel) return channel.root;
    const chain = parentChain(composer);
    const explicit = chain.find(node => THREAD_ID_ATTRIBUTES.some(name => attribute(node, name))
      || CHAT_ROOT_SELECTORS.some(selector => {
        try { return node.matches?.(selector); } catch { return false; }
      }));
    if (explicit) return explicit;

    // A generic main/body fallback is unsafe: search, checkout, and article
    // pages all expose editable fields and list items. Accept an inferred root
    // only when it contains a separate semantic transcript region with at
    // least one message-shaped descendant.
    for (const node of chain) {
      if (node === document.body || node === document.documentElement) continue;
      const transcript = queryMany(node, CHAT_TRANSCRIPT_SELECTORS)
        .find(candidate => candidate !== node
          && visible(candidate)
          && !contains(candidate, composer)
          && queryMany(candidate, MESSAGE_SELECTORS.slice(0, 12)).some(item => visible(item)));
      if (transcript) return node;
    }
    return null;
  };

  const markerFor = (composer, root) => {
    const channel = discordChannel(composer);
    if (channel?.root === root) return { value: channel.id };
    const fromComposer = firstAttribute(parentChain(composer), THREAD_ID_ATTRIBUTES);
    if (fromComposer) return fromComposer;
    const activeMarker = queryMany(root, THREAD_ID_ATTRIBUTES.map(name => `[${name}]`))
      .filter(node => visible(node))
      .find(node => (node.hasAttribute?.('aria-current')
          && attribute(node, 'aria-current').toLowerCase() !== 'false')
        || attribute(node, 'aria-selected').toLowerCase() === 'true');
    return firstAttribute(activeMarker ? [activeMarker] : [], THREAD_ID_ATTRIBUTES)
      || firstAttribute([root], THREAD_ID_ATTRIBUTES);
  };

  const identityFor = (composer, root, probe) => {
    const channel = discordChannel(composer);
    if (channel?.root === root) return channel.isDirectMessage ? channel.name : `#${channel.name}`;
    const explicit = firstAttribute(parentChain(composer), IDENTITY_ATTRIBUTES)
      || firstAttribute([root], IDENTITY_ATTRIBUTES)
      || firstAttribute(queryMany(root, IDENTITY_ATTRIBUTES.map(name => `[${name}]`)), IDENTITY_ATTRIBUTES);
    if (explicit) return explicit.value;
    const candidate = Array.isArray(probe?.strongIdentityCandidates)
      ? probe.strongIdentityCandidates.find(value => compact(value))
      : '';
    return compact(candidate, 240);
  };

  const messageDirection = (node) => {
    const explicit = [
      attribute(node, 'data-message-direction'),
      attribute(node, 'data-direction'),
      attribute(node, 'data-message-author-role'),
      attribute(node, 'data-author-role'),
    ].find(Boolean)?.toLowerCase() || '';
    if (/^(?:outgoing|sent|self|user|me|from[-_ ]?me|own)/.test(explicit)) return 'outgoing';
    if (/^(?:incoming|received|agent|operator|support|counterparty|other)/.test(explicit)) return 'incoming';
    if (booleanValue(attribute(node, 'data-outgoing'), node.hasAttribute?.('data-outgoing')) === true
      || booleanValue(attribute(node, 'data-is-outgoing'), node.hasAttribute?.('data-is-outgoing')) === true) return 'outgoing';
    if (booleanValue(attribute(node, 'data-incoming'), node.hasAttribute?.('data-incoming')) === true
      || booleanValue(attribute(node, 'data-is-incoming'), node.hasAttribute?.('data-is-incoming')) === true) return 'incoming';
    const className = compact(typeof node.className === 'string' ? node.className : '', 400).toLowerCase();
    const aria = attribute(node, 'aria-label').toLowerCase();
    if (/(?:^|[-_\s])(outgoing|sent|from-me|own-message|self-message)(?:$|[-_\s])/.test(className)
      || /^(?:you(?:\s+sent\b|[:,])|outgoing message\b|sent by you\b)/.test(aria)) return 'outgoing';
    if (/(?:^|[-_\s])(incoming|received|from-them|other-message)(?:$|[-_\s])/.test(className)) return 'incoming';
    return 'unknown';
  };

  const messageText = (node) => normalizeText(node?.innerText || node?.textContent || '');

  const messageId = (node) => [
    'data-message-id',
    'data-legacy-message-id',
    'data-message-key',
  ].map(name => attribute(node, name)).find(Boolean) || '';

  const ignoredMessageNode = (node, composer) => {
    if (contains(node, composer) || contains(composer, node) || editable(node)) return true;
    const tag = String(node.tagName || '').toLowerCase();
    if (['button', 'input', 'textarea', 'select', 'option', 'nav', 'header', 'aside'].includes(tag)) return true;
    try {
      // Chat transcripts are routinely wrapped in a single aria-live/log
      // region, so an announcing ancestor cannot disqualify its messages.
      // Only the node itself counts as a status region; interactive and
      // navigational ancestors still do.
      if (node.matches?.('[aria-live],[role="alert"],[role="status"]')) return true;
      return !!node.closest?.('button,[role="button"],[role="navigation"],nav,header,aside');
    } catch {
      return false;
    }
  };

  const discordAvatarUserId = (node) => {
    try {
      const url = new URL(attribute(node, 'src'), window.location.href);
      if (url.hostname !== 'cdn.discordapp.com') return '';
      return /^\/avatars\/(\d+)\//.exec(url.pathname)?.[1]
        || /^\/guilds\/\d+\/users\/(\d+)\/avatars\//.exec(url.pathname)?.[1]
        || '';
    } catch { return ''; }
  };

  const discordGlobalAvatarUserId = (node) => {
    try {
      const url = new URL(attribute(node, 'src'), window.location.href);
      return url.hostname === 'cdn.discordapp.com'
        ? /^\/avatars\/(\d+)\//.exec(url.pathname)?.[1] || ''
        : '';
    } catch { return ''; }
  };

  const discordDefaultAvatarIndex = (node) => {
    try {
      const url = new URL(attribute(node, 'src'), window.location.href);
      const match = url.hostname === 'cdn.discordapp.com'
        ? /^\/embed\/avatars\/(\d+)\.png$/.exec(url.pathname)
        : url.origin === window.location.origin
          ? /^\/assets\/embed\/avatars\/(\d+)\.png$/.exec(url.pathname)
          : null;
      return match?.[1] || '';
    } catch { return ''; }
  };

  const discordMessageText = (content) => {
    const read = (node) => {
      if (node?.nodeType === 3) return node.nodeValue || '';
      if (node?.nodeType !== 1 || node.hidden || attribute(node, 'aria-hidden') === 'true') return '';
      const style = getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden') return '';
      const tag = String(node.tagName || '').toLowerCase();
      if (tag === 'br') return '\n';
      if (tag === 'img') return node.matches?.('.emoji,[data-type="emoji"]') ? attribute(node, 'alt') : '';
      const text = Array.from(node.childNodes || []).map(read).join('');
      return /^(?:div|p|li|blockquote|pre)$/.test(tag) ? `${text}\n` : text;
    };
    return normalizeText(read(content));
  };

  const discordAttachmentDescriptions = (row, messageId) => {
    const accessories = query(row, `[id="message-accessories-${messageId}"]`)[0];
    if (!accessories) return [];
    const reactions = query(accessories, `[id="message-reactions-${messageId}"]`)[0];
    const selectors = [
      '[role="img"][aria-label]',
      'img[alt]',
      '[data-filename]',
      '[data-name]',
      '[class*="fileName"]',
      '[class*="filename"]',
      '[class*="embedFieldName"]',
      '[class*="embedFieldValue"]',
      '[class*="embedTitle"]',
      '[class*="embedDescription"]',
      'a[href*="/attachments/"]',
      'a[href*="/ephemeral-attachments/"]',
    ];
    const seen = new Set();
    const descriptions = [];
    for (const node of queryMany(accessories, selectors)) {
      if (!visible(node) || (reactions && contains(reactions, node))) continue;
      const labelledMedia = node.closest?.('[role="img"][aria-label]');
      if (labelledMedia && labelledMedia !== node) continue;
      const value = compact(
        attribute(node, 'aria-label')
          || attribute(node, 'alt')
          || attribute(node, 'title')
          || attribute(node, 'data-filename')
          || attribute(node, 'data-name')
          || node.innerText
          || node.textContent,
        240,
      );
      const key = canonicalText(value);
      if (!value || seen.has(key)) continue;
      seen.add(key);
      descriptions.push(value);
    }
    const pollSelector = '[class*="poll"],[data-poll]';
    const pollRoots = queryMany(accessories, [pollSelector])
      .filter(node => visible(node) && !node.parentElement?.closest(pollSelector));
    for (const node of pollRoots) {
      const value = compact(node.innerText || node.textContent, 240);
      const key = canonicalText(value);
      if (!value || seen.has(key)) continue;
      seen.add(key);
      descriptions.push(`Poll: ${value}`);
    }
    return descriptions;
  };

  const collectDiscordMessages = (channel) => {
    const account = query(document, '[class*="accountPopoutButtonWrapper"]')[0]?.parentElement;
    const ownAvatar = query(account, 'img[src*="/avatars/"]')[0];
    const ownAvatarId = discordAvatarUserId(ownAvatar);
    const ownDefaultAvatarIndex = discordDefaultAvatarIndex(ownAvatar);
    const rows = query(channel.transcript, '[role="article"][data-list-item-id]');
    const messages = [];
    let previousAuthor = '';
    let previousDirection = 'unknown';
    for (const row of rows) {
      const match = /^chat-messages___chat-messages-(\d+)-(\d+)$/.exec(attribute(row, 'data-list-item-id'));
      if (!match || match[1] !== channel.channelId || !visible(row)) continue;
      const messageId = match[2];
      const usernameNode = query(row, `[id="message-username-${messageId}"]`)[0];
      const username = query(usernameNode, '[data-text]')[0] || usernameNode;
      const system = !username && /(?:^|\s)(?:isSystemMessage|systemMessage)/.test(String(row.className || ''));
      if (system) {
        previousAuthor = '';
        previousDirection = 'unknown';
        continue;
      }
      const content = query(row, `[id="message-content-${messageId}"]`)[0];
      const text = discordMessageText(content);
      const attachments = discordAttachmentDescriptions(row, messageId);
      const body = [text, ...attachments.map(value => `Attachment: ${value}`)].filter(Boolean).join('\n');
      const author = compact(attribute(username, 'data-text') || username?.textContent, 240)
        || (!username ? previousAuthor : '');
      const avatar = username?.closest('h3')?.parentElement?.querySelector('img[src]');
      const avatarId = discordAvatarUserId(avatar);
      const globalAvatarId = discordGlobalAvatarUserId(avatar);
      const defaultAvatarIndex = discordDefaultAvatarIndex(avatar);
      let direction = 'unknown';
      if (ownAvatarId && avatarId) direction = ownAvatarId === avatarId ? 'outgoing' : 'incoming';
      else if (ownAvatarId && defaultAvatarIndex) direction = 'incoming';
      else if (ownDefaultAvatarIndex && defaultAvatarIndex
          && ownDefaultAvatarIndex !== defaultAvatarIndex) direction = 'incoming';
      else if (ownDefaultAvatarIndex && globalAvatarId) direction = 'incoming';
      else if (!username) direction = previousDirection;
      previousAuthor = author;
      previousDirection = direction;
      if (!body) continue;
      const timestamp = attribute(query(row, `[id="message-timestamp-${messageId}"]`)[0], 'datetime');
      messages.push({
        id: `discord:${channel.channelId}:${messageId}`,
        direction,
        text: body,
        ...(text ? { authoredText: text } : {}),
        ...(author ? { author } : {}),
        ...(timestamp ? { timestamp } : {}),
      });
    }
    return messages.slice(-MAX_ITEMS);
  };

  const collectMessages = (root, composer) => {
    const channel = discordChannel(composer);
    if (channel?.root === root) return collectDiscordMessages(channel);
    const candidates = queryMany(root, MESSAGE_SELECTORS)
      .filter(node => visible(node) && !ignoredMessageNode(node, composer))
      .map((node, index) => {
        const text = messageText(node);
        const id = messageId(node);
        const direction = messageDirection(node);
        const metadataScore = (id ? 4 : 0)
          + (direction !== 'unknown' ? 2 : 0)
          + (MESSAGE_SELECTORS.slice(0, 12).some(selector => {
            try { return node.matches?.(selector); } catch { return false; }
          }) ? 1 : 0);
        return {
          node,
          index,
          id,
          text,
          direction,
          metadataScore,
          author: compact(
            attribute(node, 'data-message-author')
              || attribute(node, 'data-author')
              || attribute(node, 'data-sender'),
            240,
          ),
          timestamp: compact(
            attribute(node, 'data-message-timestamp')
              || attribute(node, 'data-timestamp')
              || attribute(node, 'datetime'),
            80,
          ),
        };
      })
      .filter(item => item.text);

    const selected = [];
    for (const candidate of candidates) {
      const duplicate = selected.find(item => {
        if (item.id && candidate.id && item.id === candidate.id) return true;
        // A wrapper and the bubble inside it are one message, even when the
        // page gives each of them its own id: innerText of the ancestor
        // already repeats the descendant's text, so keeping both reports the
        // same message twice. Only DOM containment collapses entries; sibling
        // bubbles with identical text stay separate and are numbered instead.
        if (!contains(item.node, candidate.node) && !contains(candidate.node, item.node)) return false;
        return item.text === candidate.text
          || item.text.includes(candidate.text)
          || candidate.text.includes(item.text);
      });
      if (!duplicate) {
        selected.push(candidate);
      } else if (candidate.metadataScore > duplicate.metadataScore
        || (candidate.metadataScore === duplicate.metadataScore && candidate.index > duplicate.index)) {
        selected[selected.indexOf(duplicate)] = candidate;
      }
    }

    // A bubble the page does not identify is identified positionally, so the
    // ordinal has to be assigned over the whole transcript rather than over
    // the retained tail. Numbering after the cap restarts at 0 as older
    // bubbles age out, which lets a genuinely new duplicate collapse onto an
    // id the session has already seen and never surface as a delta.
    const occurrences = new Map();
    for (const item of selected) {
      const key = [
        item.direction,
        canonicalText(item.text),
        canonicalText(item.author),
        item.timestamp,
      ].join('\u001f');
      const seen = occurrences.get(key) || 0;
      occurrences.set(key, seen + 1);
      item.occurrence = seen;
    }

    // The kernel keeps the last MAX_ITEMS entries, so the newest bubbles —
    // not the oldest — must survive the cap in a long conversation.
    return selected.slice(-MAX_ITEMS).map(item => ({
      ...(item.id ? { id: item.id } : {}),
      direction: item.direction,
      text: item.text,
      occurrence: item.occurrence,
      ...(item.author ? { author: item.author } : {}),
      ...(item.timestamp ? { timestamp: item.timestamp } : {}),
    }));
  };

  const userInputFor = (root) => {
    const selectors = [
      '[data-webbrain-user-input-required]',
      '[data-requires-user-input]',
      '[data-new-user-decision-required]',
      'input[autocomplete]',
      'input[type="password"]',
      'select[data-webbrain-user-input-required]',
    ];
    for (const node of queryMany(root, selectors)) {
      if (!visible(node)) continue;
      const explicit = [
        attribute(node, 'data-webbrain-user-input-reason'),
        attribute(node, 'data-user-input-reason'),
      ].join(' ').toLowerCase();
      const autocomplete = attribute(node, 'autocomplete').toLowerCase();
      const semantic = [
        attribute(node, 'name'),
        attribute(node, 'id'),
        attribute(node, 'aria-label'),
        attribute(node, 'data-testid'),
      ].join(' ').toLowerCase();
      const type = attribute(node, 'type').toLowerCase();
      let reason = '';
      if (/otp|one[-_ ]?time|verification[-_ ]?code|security[-_ ]?code/.test(explicit)
        || autocomplete.includes('one-time-code')
        || /otp|one[-_ ]?time|verification[-_ ]?code|security[-_ ]?code/.test(semantic)) reason = 'otp';
      else if (/pin/.test(explicit) || /(?:^|[^a-z0-9])pin(?:$|[^a-z0-9])/.test(semantic)) reason = 'pin';
      else if (/payment|cc-|credit[-_ ]?card|cvc|cvv/.test(explicit)
        || /cc-|credit[-_ ]?card|cvc|cvv/.test(autocomplete)
        || /payment|credit[-_ ]?card|cvc|cvv/.test(semantic)) reason = 'payment';
      else if (/new[-_ ]?user[-_ ]?decision|decision/.test(explicit)
        || node.hasAttribute?.('data-new-user-decision-required')) reason = 'new_user_decision';
      else if (type === 'password'
        || /authentication|auth|password|login|sign[-_ ]?in/.test(explicit)
        || /(?:^|[^a-z0-9])(?:authentication|auth|password|login|sign[-_ ]?in)(?:$|[^a-z0-9])/.test(semantic)) reason = 'authentication';
      if (!reason) continue;
      const messages = {
        otp: 'A one-time code or verification code requires the user.',
        pin: 'A PIN requires the user.',
        payment: 'A payment or card verification step requires the user.',
        authentication: 'Authentication requires the user.',
        new_user_decision: 'A new user decision requires the user.',
      };
      return { required: true, reason, message: messages[reason] };
    }
    return null;
  };

  const resolveComposer = (probe, params) => {
    const ref = compact(probe?.composerRef || params.composerRef, 240);
    if (ref && typeof window.__wb_ax_lookup === 'function') {
      try {
        const node = window.__wb_ax_lookup(ref);
        if (node && visible(node)) return { node, ref };
      } catch {}
    }
    const active = document.activeElement;
    if (editable(active) && visible(active)) {
      return { node: active, ref: typeof window.__wb_ax_ref === 'function' ? window.__wb_ax_ref(active) || '' : '' };
    }
    return { node: null, ref: '' };
  };

  window.__wb_observe_chat_dom = (params = {}) => {
    try {
      const probe = params.probe && typeof params.probe === 'object' ? params.probe : {};
      const { node: composer, ref: composerRef } = resolveComposer(probe, params);
      const root = activeRoot(composer);
      if (!composer || !root) {
        return {
          success: false,
          schema: SCHEMA,
          reason: 'chat_root_unverified',
          error: !composer
            ? 'The active page does not expose a verified chat composer.'
            : 'The active editable is not inside a semantic chat root; no conversation was observed.',
        };
      }
      const marker = markerFor(composer, root);
      const conversationIdentity = identityFor(composer, root, probe);
      const conversationId = marker?.value || '';
      const url = compact(window.location?.href || '', 1000);
      const threadKey = compact(
        conversationId
          ? `dom:${conversationId}`
          : (conversationIdentity ? `identity:${conversationIdentity}` : ''),
        240,
      );
      if (!threadKey) {
        return {
          success: false,
          schema: SCHEMA,
          reason: 'chat_thread_unverified',
          error: 'The active chat does not expose a conversation-specific identity; sending is disabled until the thread can be verified.',
        };
      }
      const composerValue = composer
        ? ('value' in composer ? composer.value : (composer.innerText || composer.textContent || ''))
        : '';
      return {
        success: true,
        schema: SCHEMA,
        observedAt: new Date().toISOString(),
        ...(url ? { url } : {}),
        ...(conversationId ? { conversationId } : {}),
        ...(conversationIdentity ? { conversationIdentity } : {}),
        threadKey,
        messages: collectMessages(root, composer),
        composer: {
          available: !!composer && (probe.composerAvailable !== false),
          ...(composerRef ? { ref: composerRef } : {}),
          empty: normalizeText(composerValue).length === 0,
        },
        // A page-controlled marker is not proof that a human or virtual agent
        // is connected. Site adapters may provide trusted evidence separately.
        agentConnected: null,
        userInput: userInputFor(root),
        // Do not let page-controlled data attributes self-authorize a refund,
        // renewal change, or case number. The kernel accepts trusted evidence
        // from a future site adapter, but generic DOM observation supplies none.
        resolutionEvidence: { refund: null, autoRenewal: null, caseNumber: null },
        probe: {
          success: probe.success !== false,
          ...(probe.error ? { error: compact(probe.error, 300) } : {}),
        },
      };
    } catch (error) {
      return {
        success: false,
        schema: SCHEMA,
        error: error?.message || String(error),
      };
    }
  };
})();
