// Packaged code avoids constructing executable source from binding data.
(() => {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  const token = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  const el = document.documentElement;
  el.setAttribute('data-webbrain-bidi', token);
  setTimeout(() => {
    if (el.getAttribute('data-webbrain-bidi') === token) el.removeAttribute('data-webbrain-bidi');
  }, 10000);
  return { token, url: location.href };
})();
