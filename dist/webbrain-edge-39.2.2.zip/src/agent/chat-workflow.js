/**
 * Browser-neutral state and evidence kernel for long-running support chats.
 *
 * Page text is data. This module only consumes structured observations from
 * the content script and never interprets message text as instructions.
 * Keep the Firefox copy byte-identical.
 */

export const CHAT_WORKFLOW_SCHEMA = 'webbrain-chat-workflow/1';

export const CHAT_STATES = Object.freeze([
  'waiting_for_transfer',
  'agent_connected',
  'we_responded',
  'counterparty_replied',
  'issue_resolved',
  'needs_user_input',
  'stopped',
]);

export const CHAT_MESSAGE_DIRECTIONS = Object.freeze([
  'incoming',
  'outgoing',
  'system',
  'unknown',
]);

export const CHAT_EVENT_TYPES = Object.freeze([
  'thread_bound',
  'thread_changed',
  'agent_connected',
  'outgoing_verified',
  'counterparty_replied',
  'resolution_verified',
  'user_input_required',
  'user_input_cleared',
  'observation_only',
]);

export const CHAT_USER_INPUT_REASONS = Object.freeze([
  'otp',
  'pin',
  'payment',
  'authentication',
  'new_user_decision',
  'thread_changed',
  'unknown',
]);

const STATE_SET = new Set(CHAT_STATES);
const DIRECTION_SET = new Set(CHAT_MESSAGE_DIRECTIONS);
const EVENT_SET = new Set(CHAT_EVENT_TYPES);
const USER_INPUT_REASON_SET = new Set(CHAT_USER_INPUT_REASONS);
const MAX_MESSAGES = 200;
const MAX_NEW_MESSAGES = 20;
const MAX_MESSAGE_TEXT = 4_000;
const MAX_ID = 240;

function bounded(value, max = MAX_ID) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .trim()
    .slice(0, max);
}

export function normalizeChatText(value, max = MAX_MESSAGE_TEXT) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/\r\n?/g, '\n')
    .split('\n')
    .map(line => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join('\n')
    .slice(0, max);
}

export function canonicalChatText(value) {
  const text = normalizeChatText(value);
  try { return text.normalize('NFKC').toLocaleLowerCase(); } catch { return text.toLowerCase(); }
}

function messageTextForMatching(message) {
  return message?.authoredText ?? message?.text ?? '';
}

function hashText(value) {
  let hash = 2166136261;
  for (const char of String(value || '')) {
    hash ^= char.codePointAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

export function stableChatMessageId({
  threadKey = '',
  direction = 'unknown',
  text = '',
  author = '',
  timestamp = '',
  occurrence = 0,
} = {}) {
  const basis = [
    bounded(threadKey),
    bounded(direction, 20),
    canonicalChatText(text),
    canonicalChatText(author),
    bounded(timestamp, 80),
    Number.isInteger(occurrence) ? occurrence : 0,
  ].join('\u001f');
  return `chatmsg_${hashText(basis)}`;
}

function normalizeDirection(value) {
  const direction = bounded(value, 20).toLowerCase();
  if (DIRECTION_SET.has(direction)) return direction;
  if (/^(?:user|self|me|sent|from[-_ ]?me|outgoing)/.test(direction)) return 'outgoing';
  if (/^(?:agent|operator|support|counterparty|other|incoming|received)/.test(direction)) return 'incoming';
  return 'unknown';
}

function normalizeTriState(value) {
  if (value === true || value === 'verified' || value === 'complete') return true;
  if (value === false || value === 'missing' || value === 'incomplete') return false;
  return null;
}

function normalizeEvidence(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return {
    refund: normalizeTriState(source.refund),
    autoRenewal: normalizeTriState(source.autoRenewal ?? source.auto_renewal),
    caseNumber: normalizeTriState(source.caseNumber ?? source.case_number),
  };
}

function normalizeUserInput(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const required = source.required === true || source.userInputRequired === true;
  if (!required) return null;
  const reason = bounded(source.reason, 40).toLowerCase();
  return {
    required: true,
    reason: USER_INPUT_REASON_SET.has(reason) ? reason : 'unknown',
    message: bounded(source.message, 500),
  };
}

export function normalizeChatMessage(value, { threadKey = '', occurrence = 0 } = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const direction = normalizeDirection(value.direction ?? value.authorRole ?? value.role);
  const text = normalizeChatText(value.text ?? value.content ?? value.message);
  if (!text) return null;
  const authoredText = normalizeChatText(value.authoredText ?? value.primaryText);
  const author = bounded(value.author ?? value.authorName ?? value.sender, 240);
  const timestamp = bounded(value.timestamp ?? value.time ?? value.createdAt, 80);
  const explicitId = bounded(value.id ?? value.messageId ?? value.message_id, MAX_ID);
  return {
    id: explicitId || stableChatMessageId({ threadKey, direction, text, author, timestamp, occurrence }),
    direction,
    text,
    ...(authoredText ? { authoredText } : {}),
    ...(author ? { author } : {}),
    ...(timestamp ? { timestamp } : {}),
    ...(value.verified === true ? { verified: true } : {}),
  };
}

export function normalizeChatSnapshot(value, now = Date.now()) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const conversationId = bounded(source.conversationId ?? source.conversation_id ?? source.threadId, MAX_ID);
  const identity = bounded(source.conversationIdentity ?? source.recipient ?? source.identity, MAX_ID);
  const url = bounded(source.url, 1000);
  const threadKey = bounded(source.threadKey || conversationId || identity, MAX_ID);
  const seenOccurrences = new Map();
  const messages = [];
  const messageIds = new Set();
  for (const raw of (Array.isArray(source.messages) ? source.messages : [])) {
    const provisionalText = canonicalChatText(raw?.text ?? raw?.content ?? raw?.message);
    const provisionalDirection = normalizeDirection(raw?.direction ?? raw?.authorRole ?? raw?.role);
    const counted = seenOccurrences.get(`${provisionalDirection}\u001f${provisionalText}`) || 0;
    seenOccurrences.set(`${provisionalDirection}\u001f${provisionalText}`, counted + 1);
    // An observation that numbered its own messages before its own truncation
    // is authoritative; such a source must number every message it reports.
    const occurrence = Number.isInteger(raw?.occurrence) && raw.occurrence >= 0 ? raw.occurrence : counted;
    const message = normalizeChatMessage(raw, { threadKey, occurrence });
    if (message && !messageIds.has(message.id)) {
      messageIds.add(message.id);
      messages.push(message);
      if (messages.length > MAX_MESSAGES) messageIds.delete(messages.shift().id);
    }
  }
  const composerSource = source.composer && typeof source.composer === 'object' ? source.composer : {};
  const resolutionEvidence = normalizeEvidence(source.resolutionEvidence ?? source.resolution_evidence);
  const userInput = normalizeUserInput(source.userInput ?? source.user_input);
  return {
    schema: CHAT_WORKFLOW_SCHEMA,
    observedAt: bounded(source.observedAt ?? source.observed_at, 80) || new Date(now).toISOString(),
    ...(url ? { url } : {}),
    ...(conversationId ? { conversationId } : {}),
    ...(identity ? { conversationIdentity: identity } : {}),
    threadKey,
    messages,
    composer: {
      available: composerSource.available === true,
      ...(bounded(composerSource.ref, MAX_ID) ? { ref: bounded(composerSource.ref, MAX_ID) } : {}),
      ...(bounded(composerSource.sendRef, MAX_ID) ? { sendRef: bounded(composerSource.sendRef, MAX_ID) } : {}),
      empty: composerSource.empty === true,
    },
    agentConnected: source.agentConnected === true ? true : source.agentConnected === false ? false : null,
    userInput,
    resolutionEvidence,
  };
}

function emptySession(now = Date.now()) {
  return {
    schema: CHAT_WORKFLOW_SCHEMA,
    state: 'waiting_for_transfer',
    threadKey: '',
    seenMessageIds: [],
    sentMessageKeys: [],
    pendingOutbound: null,
    resolutionEvidence: { refund: null, autoRenewal: null, caseNumber: null },
    lastObservedAt: new Date(now).toISOString(),
    userInput: null,
    pausedState: null,
    stopReason: '',
  };
}

export function createChatSession({ threadKey = '', now = Date.now() } = {}) {
  const session = emptySession(now);
  session.threadKey = bounded(threadKey, MAX_ID);
  return session;
}

export function normalizeChatSession(value, now = Date.now()) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const state = STATE_SET.has(source.state) ? source.state : 'waiting_for_transfer';
  const evidence = normalizeEvidence(source.resolutionEvidence);
  const pending = source.pendingOutbound && typeof source.pendingOutbound === 'object'
    ? {
        key: bounded(source.pendingOutbound.key, MAX_ID),
        text: normalizeChatText(source.pendingOutbound.text),
        threadKey: bounded(source.pendingOutbound.threadKey, MAX_ID),
        ...(bounded(source.pendingOutbound.replyAnchor, MAX_ID)
          ? { replyAnchor: bounded(source.pendingOutbound.replyAnchor, MAX_ID) }
          : {}),
        attemptedAt: bounded(source.pendingOutbound.attemptedAt, 80),
        ...(bounded(source.pendingOutbound.dispatchedAt, 80)
          ? { dispatchedAt: bounded(source.pendingOutbound.dispatchedAt, 80) }
          : {}),
      }
    : null;
  return {
    schema: CHAT_WORKFLOW_SCHEMA,
    state,
    threadKey: bounded(source.threadKey, MAX_ID),
    seenMessageIds: [...new Set((Array.isArray(source.seenMessageIds) ? source.seenMessageIds : [])
      .map(value => bounded(value, MAX_ID)).filter(Boolean))].slice(-MAX_MESSAGES),
    sentMessageKeys: [...new Set((Array.isArray(source.sentMessageKeys) ? source.sentMessageKeys : [])
      .map(value => bounded(value, MAX_ID)).filter(Boolean))].slice(-MAX_MESSAGES),
    pendingOutbound: pending?.key && pending.text ? pending : null,
    resolutionEvidence: evidence,
    lastObservedAt: bounded(source.lastObservedAt, 80) || new Date(now).toISOString(),
    userInput: normalizeUserInput(source.userInput),
    pausedState: STATE_SET.has(source.pausedState) && source.pausedState !== 'needs_user_input'
      ? source.pausedState
      : null,
    stopReason: bounded(source.stopReason, 120),
  };
}

function legacyMessageKey(threadKey, text) {
  return `chatout_${hashText(`${bounded(threadKey)}\u001f${canonicalChatText(text)}`)}`;
}

function messageKey(threadKey, text, replyAnchor = 'chat_start') {
  return `chatout_${hashText(`${bounded(threadKey)}\u001f${bounded(replyAnchor, MAX_ID)}\u001f${canonicalChatText(text)}`)}`;
}

function outgoingMessageKeys(snapshot) {
  const keys = new Set();
  let replyAnchor = 'chat_start';
  for (const message of snapshot.messages) {
    if (message.direction === 'incoming') replyAnchor = message.id;
    if (message.direction === 'outgoing') keys.add(messageKey(snapshot.threadKey, messageTextForMatching(message), replyAnchor));
  }
  return keys;
}

function latestIncomingId(snapshot) {
  return [...snapshot.messages].reverse().find(message => message.direction === 'incoming')?.id || 'chat_start';
}

function evidenceComplete(evidence) {
  return evidence.refund === true && evidence.autoRenewal === true && evidence.caseNumber === true;
}

export function transitionChatState(state, event) {
  const current = STATE_SET.has(state) ? state : 'waiting_for_transfer';
  const type = EVENT_SET.has(event?.type) ? event.type : 'observation_only';
  if (type === 'user_input_required' || type === 'thread_changed') return 'needs_user_input';
  if (type === 'user_input_cleared' && current === 'needs_user_input') {
    return STATE_SET.has(event?.resumeState) && event.resumeState !== 'needs_user_input'
      ? event.resumeState
      : 'waiting_for_transfer';
  }
  if (type === 'resolution_verified') return 'issue_resolved';
  if (current === 'stopped' || current === 'issue_resolved') return current;
  if (type === 'counterparty_replied') return 'counterparty_replied';
  if (type === 'outgoing_verified') return 'we_responded';
  if (type === 'agent_connected') return 'agent_connected';
  return current;
}

export function advanceChatSession(value, rawSnapshot, now = Date.now()) {
  let session = normalizeChatSession(value, now);
  const snapshot = normalizeChatSnapshot(rawSnapshot, now);
  const events = [];
  if (!session.threadKey && snapshot.threadKey) {
    session.threadKey = snapshot.threadKey;
    events.push({ type: 'thread_bound', threadKey: snapshot.threadKey });
  } else if (session.threadKey && snapshot.threadKey && session.threadKey !== snapshot.threadKey) {
    session = {
      ...session,
      state: transitionChatState(session.state, { type: 'thread_changed' }),
      userInput: { required: true, reason: 'thread_changed', message: 'The active conversation changed. Select and verify the intended thread before continuing.' },
      stopReason: 'thread_changed',
    };
    events.push({ type: 'thread_changed', previousThreadKey: session.threadKey, threadKey: snapshot.threadKey });
    return { session, snapshot, events, newMessages: [], nextAction: 'pause_for_user' };
  }

  const known = new Set(session.seenMessageIds);
  const newMessages = snapshot.messages.filter(message => !known.has(message.id));
  const newIncoming = newMessages.filter(message => message.direction === 'incoming');
  const newOutgoing = newMessages.filter(message => message.direction === 'outgoing');
  const pendingDiscordDelivery = discordPendingDeliveryMatch(session.pendingOutbound, snapshot, newMessages);
  const outgoingKeys = new Set(session.sentMessageKeys);
  for (const key of outgoingMessageKeys(snapshot)) outgoingKeys.add(key);
  if (pendingDiscordDelivery && session.pendingOutbound) outgoingKeys.add(session.pendingOutbound.key);

  if (snapshot.userInput?.required) {
    events.push({ type: 'user_input_required', ...snapshot.userInput });
  } else {
    // A thread_changed pause is only lifted by evidence that the bound thread
    // is active again — either an explicit rebind (which starts a fresh
    // session) or an observation of the same threadKey. Without the second
    // case the pause is escaped implicitly by the next state transition while
    // stopReason stays 'thread_changed' forever, which would keep the rebind
    // precondition permanently satisfied.
    const boundThreadObserved = !!session.threadKey && session.threadKey === snapshot.threadKey;
    if (session.state === 'needs_user_input'
        && (session.stopReason !== 'thread_changed' || boundThreadObserved)) {
      events.push({ type: 'user_input_cleared', resumeState: session.pausedState });
    }
    if (evidenceComplete(snapshot.resolutionEvidence)) {
      events.push({ type: 'resolution_verified', evidence: snapshot.resolutionEvidence });
    } else if (newIncoming.length) {
      events.push({ type: 'counterparty_replied', messages: newIncoming.slice(-MAX_NEW_MESSAGES).map(message => message.id) });
    } else if (newOutgoing.length) {
      events.push({ type: 'outgoing_verified', messages: newOutgoing.slice(-MAX_NEW_MESSAGES).map(message => message.id) });
    } else if (pendingDiscordDelivery) {
      events.push({
        type: 'outgoing_verified',
        messages: [pendingDiscordDelivery.id],
        evidence: 'discord_pending_delivery',
      });
    } else if (snapshot.agentConnected === true && session.state === 'waiting_for_transfer') {
      events.push({ type: 'agent_connected' });
    } else if (events.length === 0) {
      events.push({ type: 'observation_only' });
    }
  }

  let nextState = session.state;
  for (const event of events) nextState = transitionChatState(nextState, event);
  const visibleOutgoingKeys = outgoingMessageKeys(snapshot);
  // The anchored key is recomputed from DOM order, so a counterparty message
  // that renders after a send could move our anchor and the key never matches,
  // stranding the pending record. A newly visible outgoing bubble carrying the
  // pending text is the same proof of delivery without depending on the anchor.
  const matchedPending = session.pendingOutbound
    && (visibleOutgoingKeys.has(session.pendingOutbound.key)
      || newOutgoing.some(message => canonicalChatText(messageTextForMatching(message)) === canonicalChatText(session.pendingOutbound.text))
      || !!pendingDiscordDelivery
      || (!session.pendingOutbound.replyAnchor
        && session.pendingOutbound.key === legacyMessageKey(snapshot.threadKey, session.pendingOutbound.text)));
  const clearUserInput = events.some(event => event.type === 'user_input_cleared');
  const pauseState = session.state === 'needs_user_input'
    ? session.pausedState
    : session.state;
  session = {
    ...session,
    state: nextState,
    seenMessageIds: [...new Set([...session.seenMessageIds, ...snapshot.messages.map(message => message.id)])].slice(-MAX_MESSAGES),
    sentMessageKeys: [...outgoingKeys].slice(-MAX_MESSAGES),
    pendingOutbound: matchedPending ? null : session.pendingOutbound,
    resolutionEvidence: snapshot.resolutionEvidence,
    lastObservedAt: snapshot.observedAt,
    userInput: snapshot.userInput,
    pausedState: snapshot.userInput?.required
      ? pauseState
      : (clearUserInput ? null : session.pausedState),
    stopReason: snapshot.userInput?.required
      ? snapshot.userInput.reason
      : (clearUserInput ? '' : session.stopReason),
  };
  const resumedReply = clearUserInput && session.state === 'counterparty_replied';
  const nextAction = session.userInput?.required
    ? 'pause_for_user'
    : session.state === 'issue_resolved'
      ? 'stop'
      : (newIncoming.length || resumedReply)
        ? 'reply'
        : session.state === 'waiting_for_transfer'
          ? 'schedule_resume'
          : 'observe';
  return {
    session,
    snapshot,
    pendingDeliveryVerified: !!pendingDiscordDelivery,
    events,
    newMessages: newMessages.slice(-MAX_NEW_MESSAGES),
    newMessagesTruncated: newMessages.length > MAX_NEW_MESSAGES,
    nextAction,
  };
}

export function decideChatSend(value, rawSnapshot, text, now = Date.now()) {
  const session = normalizeChatSession(value, now);
  const snapshot = normalizeChatSnapshot(rawSnapshot, now);
  // Normalize one character past the cap so an over-long body is rejected
  // rather than silently truncated into a different message than requested.
  const body = normalizeChatText(text, MAX_MESSAGE_TEXT + 1);
  if (!body) return { ok: false, reason: 'empty_message', error: 'A non-empty chat message is required.' };
  if (body.length > MAX_MESSAGE_TEXT) return { ok: false, reason: 'message_too_long', error: 'Chat messages must be 4,000 characters or fewer.' };
  if (session.userInput?.required || snapshot.userInput?.required) {
    return { ok: false, reason: 'user_input_required', error: 'Pause the chat until the user completes the required verification or decision.' };
  }
  if (session.state === 'issue_resolved' || session.state === 'stopped') {
    return { ok: false, reason: 'terminal_session', error: 'The chat session is terminal; do not send another message.' };
  }
  if (!session.threadKey || !snapshot.threadKey || session.threadKey !== snapshot.threadKey) {
    return { ok: false, reason: 'thread_unverified', error: 'The active conversation is not bound to the stored chat session.' };
  }
  if (snapshot.composer.available !== true) {
    return { ok: false, reason: 'composer_unavailable', error: 'The active conversation composer is not available.' };
  }
  if (snapshot.composer.empty !== true) {
    return { ok: false, reason: 'composer_not_empty', error: 'Chat send blocked because the composer contains a user draft. Clear or reconcile the draft before sending.' };
  }
  const replyAnchor = latestIncomingId(snapshot);
  const key = messageKey(snapshot.threadKey, body, replyAnchor);
  const latestIncomingIndex = snapshot.messages.map(message => message.direction).lastIndexOf('incoming');
  const sameReplyAlreadyVisible = snapshot.messages.some((message, index) => (
    index > latestIncomingIndex
      && message.direction === 'outgoing'
      && canonicalChatText(messageTextForMatching(message)) === canonicalChatText(body)
  ));
  if (session.sentMessageKeys.includes(key)
      || sameReplyAlreadyVisible) {
    return { ok: false, duplicate: true, reason: 'already_sent', messageKey: key, error: 'This exact message is already visible as an outgoing message in this conversation.' };
  }
  if (session.pendingOutbound) {
    return {
      ok: false,
      duplicate: true,
      pending: true,
      reason: 'send_pending',
      messageKey: key,
      pendingMessageKey: session.pendingOutbound.key,
      error: 'An outbound message is still pending verification; observe the conversation or explicitly reconcile its outcome before sending again.',
    };
  }
  return {
    ok: true,
    messageKey: key,
    replyAnchor,
    threadKey: snapshot.threadKey,
    text: body,
    attemptedAt: new Date(now).toISOString(),
  };
}

export function markChatSendPending(value, decision, now = Date.now()) {
  const session = normalizeChatSession(value, now);
  if (!decision?.ok || !decision.messageKey || !decision.threadKey) return session;
  return {
    ...session,
    pendingOutbound: {
      key: bounded(decision.messageKey, MAX_ID),
      text: normalizeChatText(decision.text),
      threadKey: bounded(decision.threadKey, MAX_ID),
      ...(bounded(decision.replyAnchor, MAX_ID)
        ? { replyAnchor: bounded(decision.replyAnchor, MAX_ID) }
        : {}),
      attemptedAt: bounded(decision.attemptedAt, 80) || new Date(now).toISOString(),
    },
  };
}

function discordPendingDeliveryMatch(pending, snapshot, newMessages) {
  if (!pending || !snapshot.threadKey.startsWith('dom:discord:')
      || pending.threadKey !== snapshot.threadKey
      || snapshot.composer.available !== true || snapshot.composer.empty !== true
      || !pending.dispatchedAt) return null;
  const dispatchedAt = Date.parse(pending.dispatchedAt);
  const observedAt = Date.parse(snapshot.observedAt);
  if (!Number.isFinite(dispatchedAt) || !Number.isFinite(observedAt)
      || observedAt < dispatchedAt - 5_000) return null;
  const matchingMessages = newMessages.filter(message => (
    canonicalChatText(messageTextForMatching(message)) === canonicalChatText(pending.text)
  ));
  // Discord default avatars and server nicknames do not identify an author.
  // Correlate delivery only after a persisted successful dispatch, with one
  // fresh exact-text bubble and an empty composer; leave its direction unchanged.
  if (matchingMessages.length !== 1 || matchingMessages[0].direction !== 'unknown') return null;
  const [candidate] = matchingMessages;
  const messageAt = Date.parse(candidate.timestamp || '');
  if (!Number.isFinite(messageAt)
      || messageAt < dispatchedAt - 5_000 || messageAt > dispatchedAt + 5_000
      || messageAt > observedAt + 5_000) return null;
  return candidate;
}

export function serializeChatSession(value, now = Date.now()) {
  return normalizeChatSession(value, now);
}
