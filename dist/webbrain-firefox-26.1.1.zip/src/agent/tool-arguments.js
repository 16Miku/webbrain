function isPlainObject(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function valueMatchesType(value, type) {
  if (type === 'object') return isPlainObject(value);
  if (type === 'array') return Array.isArray(value);
  if (type === 'integer') return Number.isInteger(value);
  if (type === 'number') return typeof value === 'number' && Number.isFinite(value);
  if (type === 'null') return value === null;
  return typeof value === type;
}

function validationFailure(toolName, invalidArguments, detail) {
  const fields = [...new Set(invalidArguments.map(String))];
  return {
    ok: false,
    result: {
      success: false,
      invalidArguments: true,
      invalidToolArguments: true,
      noDispatch: true,
      dispatched: false,
      errorCode: 'invalid_tool_arguments',
      invalidArgumentNames: fields,
      error: `${toolName || 'Tool'} could not run because its arguments do not match the advertised schema. Re-emit the call with only declared, valid arguments; do not assume the action happened.`,
      detail,
    },
  };
}

function validateValue(value, schema, path, failures) {
  if (!schema || typeof schema !== 'object') return;
  const acceptedTypes = Array.isArray(schema.type) ? schema.type : (schema.type ? [schema.type] : []);
  if (acceptedTypes.length && !acceptedTypes.some(type => valueMatchesType(value, type))) {
    failures.push(path);
    return;
  }
  if (Array.isArray(schema.enum) && !schema.enum.some(candidate => Object.is(candidate, value))) {
    failures.push(path);
    return;
  }
  if (typeof value === 'string') {
    if (Number.isFinite(schema.minLength) && value.length < schema.minLength) failures.push(path);
    if (Number.isFinite(schema.maxLength) && value.length > schema.maxLength) failures.push(path);
  }
  if (Array.isArray(value) && schema.items) {
    value.forEach((item, index) => validateValue(item, schema.items, `${path}[${index}]`, failures));
  }
  if (!isPlainObject(value)) return;
  const properties = isPlainObject(schema.properties) ? schema.properties : {};
  for (const required of Array.isArray(schema.required) ? schema.required : []) {
    if (!Object.prototype.hasOwnProperty.call(value, required)) failures.push(`${path}.${required}`);
  }
  if (schema.additionalProperties !== true && typeof schema.additionalProperties !== 'object') {
    for (const key of Object.keys(value)) {
      if (!Object.prototype.hasOwnProperty.call(properties, key)) failures.push(`${path}.${key}`);
    }
  }
  for (const [key, child] of Object.entries(value)) {
    if (Object.prototype.hasOwnProperty.call(properties, key)) {
      validateValue(child, properties[key], `${path}.${key}`, failures);
    }
  }
}

function validateClickTarget(args) {
  const text = typeof args.text === 'string' && args.text.trim() !== '';
  const selector = typeof args.selector === 'string' && args.selector.trim() !== '';
  const index = Number.isInteger(args.index) && args.index >= 0;
  const hasX = typeof args.x === 'number' && Number.isFinite(args.x);
  const hasY = typeof args.y === 'number' && Number.isFinite(args.y);
  const coordinates = hasX && hasY && !(args.x === 0 && args.y === 0);
  const strategies = [text, selector, index, coordinates].filter(Boolean).length;
  const invalidCoordinates = hasX !== hasY || ((hasX && hasY) && args.x === 0 && args.y === 0);
  if (strategies !== 1 || invalidCoordinates || (args.from_screenshot === true && !coordinates)) {
    return validationFailure('click', ['target'], 'Provide exactly one target strategy: non-empty text, non-empty selector, a non-negative integer index, or a complete non-zero x/y coordinate pair.');
  }
  return null;
}

export function closeToolDefinition(tool) {
  if (!tool?.function) return tool;
  const parameters = tool.function.parameters;
  if (!isPlainObject(parameters)) return tool;
  const closeSchema = (schema) => {
    if (!isPlainObject(schema)) return schema;
    const closed = { ...schema };
    if (isPlainObject(schema.properties)) {
      closed.properties = Object.fromEntries(Object.entries(schema.properties).map(([key, child]) => [key, closeSchema(child)]));
    }
    if (schema.items) closed.items = closeSchema(schema.items);
    if (schema.type === 'object' && schema.additionalProperties === undefined) closed.additionalProperties = false;
    return closed;
  };
  return {
    ...tool,
    function: {
      ...tool.function,
      parameters: closeSchema(parameters),
    },
  };
}

export function closeToolDefinitions(tools) {
  return Array.isArray(tools) ? tools.map(closeToolDefinition) : [];
}

export function validateToolArguments(toolName, args, parameters) {
  if (!isPlainObject(args)) {
    return validationFailure(toolName, ['$'], 'Arguments must be a JSON object.');
  }
  const closedParameters = isPlainObject(parameters)
    ? { ...parameters, additionalProperties: false }
    : { type: 'object', properties: {}, additionalProperties: false };
  const failures = [];
  validateValue(args, closedParameters, '$', failures);
  if (failures.length) {
    return validationFailure(toolName, failures, `Invalid or undeclared argument(s): ${[...new Set(failures)].join(', ')}.`);
  }
  if (toolName === 'click') {
    const clickFailure = validateClickTarget(args);
    if (clickFailure) return clickFailure;
  }
  return { ok: true, args };
}
