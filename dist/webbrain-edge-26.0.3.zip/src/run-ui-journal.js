export const RUN_UI_EVENT_LIMIT = 256;
export const RUN_UI_TEXT_DELTA_PERSIST_DELAY_MS = 200;
export const RUN_UI_STREAM_TEXT_LIMIT = 100000;

export function createRunRequestId(tabId, supplied = '') {
  const clean = String(supplied || '').trim();
  return clean || `req_${tabId}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export function runUiSnapshotForRequest(snapshot, requestedRequestId = '') {
  const requested = String(requestedRequestId || '');
  if (!requested) return snapshot || null;
  return String(snapshot?.requestId || '') === requested ? snapshot : null;
}

export function compactRunUiData(type, data) {
  if (!data || typeof data !== 'object') return data;
  if (type === 'tool_result') {
    const result = data.result || {};
    return {
      name: data.name,
      result: {
        success: result.success,
        ok: result.ok,
        error: result.error ? String(result.error).slice(0, 1000) : undefined,
        warning: result.warning ? String(result.warning).slice(0, 1000) : undefined,
        summary: result.summary ? String(result.summary).slice(0, 2000) : undefined,
      },
    };
  }
  if (type === 'text' || type === 'text_delta') {
    return { ...data, content: String(data.content || '').slice(0, 30000) };
  }
  return data;
}

export class RunUiPersistenceScheduler {
  constructor({
    persist,
    delayMs = RUN_UI_TEXT_DELTA_PERSIST_DELAY_MS,
    setTimeoutFn = setTimeout,
    clearTimeoutFn = clearTimeout,
  } = {}) {
    if (typeof persist !== 'function') throw new TypeError('persist must be a function');
    this.persist = persist;
    this.delayMs = delayMs;
    // Browser timer functions are Web APIs with receiver checks. Calling a
    // saved setTimeout/clearTimeout as an instance property makes `this` the
    // scheduler and Chrome throws "Illegal invocation" on the first streamed
    // text delta. Bind injected and native timers to the actual global scope.
    this.setTimeoutFn = setTimeoutFn.bind(globalThis);
    this.clearTimeoutFn = clearTimeoutFn.bind(globalThis);
    this.pending = new Map();
  }

  _persist(tabId, snapshot) {
    try {
      return Promise.resolve(this.persist(tabId, snapshot));
    } catch (error) {
      return Promise.reject(error);
    }
  }

  _take(tabId, cancelTimer = true) {
    const pending = this.pending.get(tabId);
    if (!pending) return null;
    this.pending.delete(tabId);
    if (cancelTimer && pending.timer != null) this.clearTimeoutFn(pending.timer);
    return pending.snapshot;
  }

  defer(tabId, snapshot) {
    const existing = this.pending.get(tabId);
    if (existing) {
      existing.snapshot = snapshot;
      return;
    }
    const pending = { snapshot, timer: null };
    this.pending.set(tabId, pending);
    pending.timer = this.setTimeoutFn(() => {
      const latest = this._take(tabId, false);
      if (latest) void this._persist(tabId, latest).catch(() => {});
    }, this.delayMs);
  }

  persistNow(tabId, snapshot) {
    this.cancel(tabId);
    return this._persist(tabId, snapshot);
  }

  flush(tabId) {
    const snapshot = this._take(tabId);
    return snapshot ? this._persist(tabId, snapshot) : null;
  }

  cancel(tabId) {
    this._take(tabId);
  }
}

export class RunUiJournal {
  constructor({ eventLimit = RUN_UI_EVENT_LIMIT, onChange = null } = {}) {
    this.eventLimit = eventLimit;
    this.onChange = onChange;
    this.snapshots = new Map();
  }

  _changed(tabId, snapshot, change = {}) {
    if (typeof this.onChange === 'function') this.onChange(tabId, snapshot, change);
    return snapshot;
  }

  begin(tabId, requestId = '', metadata = {}) {
    const snapshot = {
      tabId,
      requestId: createRunRequestId(tabId, requestId),
      mode: String(metadata?.mode || ''),
      kind: metadata?.kind === 'continue' ? 'continue' : 'chat',
      foreground: metadata?.foreground === true,
      runId: null,
      status: 'running',
      seq: 0,
      ackedSeq: 0,
      truncatedBeforeSeq: 0,
      events: [],
      pendingPlanId: null,
      lastPlanResolution: null,
      finalContent: '',
      successfulDone: false,
      hadError: false,
      lastError: '',
      pendingToolCall: null,
      streamedText: '',
      streamedTextStartSeq: 0,
      streamedTextSeq: 0,
      streamedTextTruncated: false,
      startedAt: Date.now(),
      endedAt: null,
    };
    this.snapshots.set(tabId, snapshot);
    return this._changed(tabId, snapshot);
  }

  resume(tabId, requestId = '', metadata = {}) {
    const snapshot = this.snapshots.get(tabId);
    if (!snapshot || String(snapshot.requestId) !== String(requestId)) return null;
    if (metadata?.mode) snapshot.mode = String(metadata.mode);
    if (typeof metadata?.foreground === 'boolean') snapshot.foreground = metadata.foreground;
    if (!snapshot.kind && metadata?.kind) {
      snapshot.kind = metadata.kind === 'continue' ? 'continue' : 'chat';
    }
    snapshot.status = 'running';
    snapshot.pendingPlanId = null;
    snapshot.finalContent = '';
    snapshot.successfulDone = false;
    snapshot.endedAt = null;
    return this._changed(tabId, snapshot);
  }

  record(tabId, requestId, type, data, runId = null) {
    const snapshot = this.snapshots.get(tabId);
    if (!snapshot || snapshot.requestId !== requestId) return null;
    snapshot.runId = runId || snapshot.runId || null;
    const event = {
      seq: ++snapshot.seq,
      type,
      data: compactRunUiData(type, data),
      ts: Date.now(),
    };
    snapshot.events.push(event);
    if (type === 'text_delta') {
      const chunk = String(event.data?.content || '');
      if (!snapshot.streamedText && !snapshot.streamedTextTruncated) {
        snapshot.streamedTextStartSeq = event.seq;
      }
      snapshot.streamedTextSeq = event.seq;
      if (!snapshot.streamedTextTruncated) {
        const nextText = snapshot.streamedText + chunk;
        if (nextText.length <= RUN_UI_STREAM_TEXT_LIMIT) {
          snapshot.streamedText = nextText;
        } else {
          snapshot.streamedText = '';
          snapshot.streamedTextStartSeq = 0;
          snapshot.streamedTextTruncated = true;
        }
      }
    } else if (type === 'text' || type === 'tool_call') {
      snapshot.streamedText = '';
      snapshot.streamedTextStartSeq = 0;
      snapshot.streamedTextSeq = 0;
      snapshot.streamedTextTruncated = false;
    }
    while (snapshot.events.length > this.eventLimit) {
      const removed = snapshot.events.shift();
      snapshot.truncatedBeforeSeq = removed?.seq || snapshot.truncatedBeforeSeq;
    }
    if (type === 'plan_review') {
      snapshot.status = 'awaiting_plan';
      snapshot.pendingPlanId = String(data?.planId || '') || null;
      snapshot.lastPlanResolution = null;
    }
    if (type === 'plan_resolved') {
      snapshot.status = 'running';
      if (!data?.planId || String(data.planId) === String(snapshot.pendingPlanId)) snapshot.pendingPlanId = null;
      snapshot.lastPlanResolution = {
        planId: String(data?.planId || ''),
        decision: String(data?.decision || ''),
      };
    }
    if (type === 'tool_call' && data?.outcomeUnknown === true) {
      snapshot.pendingToolCall = {
        name: String(data?.name || ''),
        seq: event.seq,
      };
    }
    if (type === 'tool_result'
        && data?.name === 'done'
        && data?.result?.done === true
        && data?.result?.outcome === 'success'
        && data?.result?.success !== false
        && !data?.result?.error
        && !data?.result?.blockedDone) {
      snapshot.successfulDone = true;
    }
    if (type === 'error' || type === 'attachment_rejected' || type === 'max_steps_reached') {
      snapshot.hadError = true;
      snapshot.lastError = String(
        data?.message
        || data?.error
        || (type === 'max_steps_reached' ? 'The run reached its maximum step limit.' : ''),
      ).slice(0, 2000);
    }
    this._changed(tabId, snapshot, { eventType: type });
    return { ...event, requestId: snapshot.requestId, runId: snapshot.runId };
  }

  settleToolCall(tabId, requestId, name = '') {
    const snapshot = this.snapshots.get(tabId);
    if (!snapshot || snapshot.requestId !== requestId || !snapshot.pendingToolCall) return null;
    if (name && snapshot.pendingToolCall.name && snapshot.pendingToolCall.name !== String(name)) return null;
    snapshot.pendingToolCall = null;
    return this._changed(tabId, snapshot);
  }

  finish(tabId, requestId, status, finalContent = '', runId = null) {
    const snapshot = this.snapshots.get(tabId);
    if (!snapshot || snapshot.requestId !== requestId) return null;
    snapshot.runId = runId || snapshot.runId || null;
    snapshot.status = status;
    snapshot.pendingPlanId = null;
    snapshot.pendingToolCall = null;
    snapshot.finalContent = String(finalContent || '').slice(0, 30000);
    snapshot.endedAt = Date.now();
    const event = {
      seq: ++snapshot.seq,
      type: 'run_complete',
      data: { status: snapshot.status, finalContent: snapshot.finalContent, endedAt: snapshot.endedAt },
      ts: snapshot.endedAt,
    };
    snapshot.events.push(event);
    while (snapshot.events.length > this.eventLimit) {
      const removed = snapshot.events.shift();
      snapshot.truncatedBeforeSeq = removed?.seq || snapshot.truncatedBeforeSeq;
    }
    return this._changed(tabId, snapshot);
  }

  restore(tabId, snapshot) {
    if (!snapshot || typeof snapshot !== 'object') return null;
    if (snapshot.successfulDone !== true) snapshot.successfulDone = false;
    if (snapshot.hadError !== true) snapshot.hadError = false;
    if (typeof snapshot.lastError !== 'string') snapshot.lastError = '';
    if (!snapshot.pendingToolCall || typeof snapshot.pendingToolCall !== 'object') {
      snapshot.pendingToolCall = null;
    }
    if (typeof snapshot.mode !== 'string') snapshot.mode = '';
    if (snapshot.kind !== 'continue' && snapshot.kind !== 'chat') snapshot.kind = 'chat';
    if (snapshot.foreground !== true) snapshot.foreground = false;
    if (typeof snapshot.streamedText !== 'string') snapshot.streamedText = '';
    if (snapshot.streamedText.length > RUN_UI_STREAM_TEXT_LIMIT) {
      snapshot.streamedText = '';
      snapshot.streamedTextTruncated = true;
    } else if (snapshot.streamedTextTruncated !== true) {
      snapshot.streamedTextTruncated = false;
    }
    const restoredStreamStartSeq = Number(snapshot.streamedTextStartSeq || 0);
    const restoredStreamSeq = Number(snapshot.streamedTextSeq || 0);
    snapshot.streamedTextStartSeq = Number.isFinite(restoredStreamStartSeq) ? Math.max(0, restoredStreamStartSeq) : 0;
    snapshot.streamedTextSeq = Number.isFinite(restoredStreamSeq) ? Math.max(0, restoredStreamSeq) : 0;
    if (!snapshot.lastPlanResolution || typeof snapshot.lastPlanResolution !== 'object') {
      snapshot.lastPlanResolution = null;
    }
    this.snapshots.set(tabId, snapshot);
    return snapshot;
  }

  acknowledge(tabId, requestId, seq) {
    const snapshot = this.snapshots.get(tabId);
    const numericSeq = Number(seq);
    if (!snapshot || snapshot.requestId !== requestId || !Number.isFinite(numericSeq)) return null;
    snapshot.ackedSeq = Math.max(Number(snapshot.ackedSeq || 0), numericSeq);
    snapshot.events = snapshot.events.filter(event => Number(event?.seq || 0) > snapshot.ackedSeq);
    snapshot.truncatedBeforeSeq = Math.max(Number(snapshot.truncatedBeforeSeq || 0), snapshot.ackedSeq);
    return this._changed(tabId, snapshot);
  }

  get(tabId) {
    return this.snapshots.get(tabId) || null;
  }

  clear(tabId) {
    this.snapshots.delete(tabId);
  }
}
