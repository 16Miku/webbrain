/**
 * Shared offscreen-document lifecycle helper.
 *
 * Chrome MV3 allows only ONE offscreen document per extension at a time,
 * and the set of `reasons` declared at createDocument time is fixed — you
 * cannot add reasons later. So both consumers of the offscreen document
 * (the localhost-fetch proxy in offscreen.js, local WebGPU inference worker,
 * PDF text extraction in pdf-extraction-host.js,
 * offline SQLite/E5 retrieval workers,
 * large-file staging in
 * skill-download.js, Emergency Box downloads in emergency-download-host.js,
 * the tab-recorder in recorder.js, and the local controller bridge in
 * cloud-bridge.js) must agree on a single
 * createDocument call that lists
 * every reason either of them might ever need.
 *
 * Callers:
 *   • providers/fetch-with-fallback.js — needs the doc when a direct fetch
 *     to a localhost LLM server fails (Private Network Access workaround).
 *   • background.js (record routes) — needs the doc to host the
 *     MediaRecorder and Web Audio mixer when recording starts.
 *   • background.js (local controller bridge routes) — needs the doc to keep
 *     an outbound WebSocket open to the local sidecar.
 *
 * Both call `ensureOffscreen()` lazily; whichever fires first creates the
 * doc with the unified reason set, and the second one no-ops via the
 * `hasDocument()` check.
 */

const OFFSCREEN_URL = 'src/offscreen/offscreen.html';
const OFFSCREEN_REASONS = [
  // Localhost fetch proxy — no perfectly matching reason, LOCAL_STORAGE is
  // what we've used historically.
  'LOCAL_STORAGE',
  // Large validated skill downloads are staged in OPFS and exposed through a
  // short-lived blob URL so chrome.downloads never re-fetches the remote URL.
  'BLOBS',
  // The local inference bridge creates a dedicated module Worker for WebGPU/ONNX
  // inference. Reasons are immutable after the document is created, so this
  // must be present even when another consumer creates the shared host first.
  'WORKERS',
  // Tab recorder needs DISPLAY_MEDIA (chrome.tabCapture stream pulls in as
  // display media) and USER_MEDIA (mic via getUserMedia).
  'DISPLAY_MEDIA',
  'USER_MEDIA',
  // Conditional watch alerts must play when no side panel is open.
  'AUDIO_PLAYBACK',
];
const OFFSCREEN_JUSTIFICATION =
  'Proxy localhost requests; parse PDFs; run local WebGPU models and offline reference search; stage validated large downloads; capture active tab and mic; maintain a localhost controller WebSocket; play conditional watch alerts.';

let ready = false;
let inflight = null;

async function offscreenDocumentExists() {
  try {
    return await chrome.offscreen.hasDocument();
  } catch {
    return null;
  }
}

export async function ensureOffscreen() {
  if (inflight) return inflight;
  inflight = (async () => {
    const exists = await offscreenDocumentExists();
    if (exists === true) {
      ready = true;
      return;
    }
    if (exists === null && ready) return;
    ready = false;
    try {
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_URL,
        reasons: OFFSCREEN_REASONS,
        justification: OFFSCREEN_JUSTIFICATION,
      });
      ready = true;
    } catch (e) {
      // Race: another caller created it between hasDocument() and us.
      if (String(e?.message || e).includes('already exists')) {
        ready = true;
        return;
      }
      throw e;
    }
  })();
  try {
    await inflight;
  } finally {
    inflight = null;
  }
}
